package com.retos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @ autor Paola Martinez
 **/
@SpringBootApplication
public class CacharreroApplication {

    public static void main(String[] args) {
        SpringApplication.run(CacharreroApplication.class, args);
    }

}
